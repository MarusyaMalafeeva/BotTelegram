import telebot
from datetime import datetime, date
from telebot.types import Message
from TOKEN import TOKEN
from client.telegram_client import TelegramClient
from client.SQLclient import UserActioner, SQLiteClient

API_TOKEN = TOKEN
ADMIN_CHAT_ID = 1400493857


# мы строили бот на telebot.TeleBot, щас подключаем к TelegramClient и базе данных
class MyBot(telebot.TeleBot):
    def __init__(self, telegram_client: TelegramClient, user_actioner: UserActioner, *args, **kwargs):
        # инициируй класс из элементов в скобках и присвой им следующее:
        super().__init__(*args, **kwargs)
        self.telegram_client = telegram_client
        self.user_actioner = user_actioner

    # мы написали новый класс, который содержит атрибуты типа TelegramClient и UserActioner
    # и наследует аргументы и ключевые аргументы класса TeleBot.

    def setup_resources(self):
        self.user_actioner.setup()

    # установить ресурсы = юзер подключен к базе данных
    def shutdown_resources(self):
        self.user_actioner.shutdown()

    # снести ресурсы = нет коннекта юзера с базой данных
    def shutdown(self):
        self.shutdown_resources()
    # снести все = снести ресурсы


telegram_client = TelegramClient(token=TOKEN, base_url="https://api.telegram.org")
user_actioner = UserActioner(SQLiteClient('users.db'))
bot = MyBot(token=TOKEN, telegram_client=telegram_client, user_actioner=user_actioner)
bot.setup_resources()


# мы отдали боту новые методы, которые нам нужны в коде
# присвоили боту новый расширенные класс
# установили все


# обработчик команды /start
# команда старт = бот получает инфу на юзера (используем методы класса Message)
@bot.message_handler(commands=['start'])
def start(message: Message):
    user_id = message.from_user.id
    username = message.from_user.username
    chat_id = message.chat.id

    # подключаем юзера к базе данных
    user = bot.user_actioner.get_user(user_id=str(user_id))
    if not user:
        bot.user_actioner.create_user(user_id=str(user_id), username=username, chat_id=chat_id)

    bot.reply_to(
        message=message, text=f"Здраствуйте, {message.from_user.username}! Я, Deadline Bot, напомню вам о дедлайнах\n"
                              f"Чтобы создать напоминание введите команду /create"
    )


# бот обработчик команды /create
# команда приветственная речь = бот отвечает на предыдущее сообщение
# связываем сообщение со следующей функцией
@bot.message_handler(commands=['create'])
def say_standup_speech(message: Message):
    bot.reply_to(message, text="О чем вам напомнить?")
    bot.register_next_step_handler(message, create_remind)


# подключаем напоминание к базе данных
# отправляем админу сообщение о юзере
# просим ввести дату дедлайна
# связываем сообщение со следующей фунцией
def create_remind(message: Message):
    bot.user_actioner.create_remind(message=message.text, user_id=str(message.from_user.id))
    bot.send_message(chat_id=ADMIN_CHAT_ID,
                     text=f"Пользователь {message.from_user.username} попросил напомнить:\n {message.text}")
    bot.send_message(message.chat.id, text='Введите дату и время в формате ГГГГ-ММ-ДД чч:мм')
    bot.register_next_step_handler(message, reminder_set)


# устанавливаем время напоминания
def reminder_set(message):
    try:
        reminder_time = datetime.strptime(message.text, '%Y-%m-%d %H:%M')
        now = datetime.now()
        delta = reminder_time - now
        if delta.total_seconds() <= 0:
            bot.send_message(message.chat.id, 'Вы ввели прошедшую дату, попробуйте еще раз.')
        else:
            bot.user_actioner.create_date(user_id=str(message.from_user.id), user_date=reminder_time)
            bot.send_message(message.chat.id, 'Напоминание установлено на {}.'.format(reminder_time))
    except ValueError:
        bot.send_message(message.chat.id, 'Вы ввели неверный формат даты и времени, попробуйте еще раз.')


# создаём сообщение об ошибке
# на выходе получаем сообщение: время:::класс:::ошибка:::тайное послание
def create_err_message(err: Exception) -> str:
    return f"{datetime.now()} ::: {err.__class__} ::: {err} кто-то обкосячился"


# призываем анонимную функцию которая обрабатывает другие входящие сообщение
@bot.message_handler(func=lambda message: True)
def handle_all_message(message):
    bot.send_message(message.chat.id, 'Я не понимаю, что вы говорите. Чтобы создать напоминание, введите /create.')


# запускаем бесконечный цикл работы бота
while True:
    try:
        bot.setup_resources()
        bot.polling()
    except Exception as err:
        bot.telegram_client.post(method="sendMessage", params={'text': create_err_message(err),
                                                               'chat_id': ADMIN_CHAT_ID})
        bot.shutdown()
# try-expect = делай, что говорят - исключение
