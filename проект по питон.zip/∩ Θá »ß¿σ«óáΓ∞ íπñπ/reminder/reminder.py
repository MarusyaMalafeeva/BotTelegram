import time

from client.SQLclient import SQLiteClient
from client.telegram_client import TelegramClient
from TOKEN import TOKEN

API_TOKEN = TOKEN


# ура мы опять пишем класс, надеюсь это последний
class Reminder:
    # возьми из бд id и сообщение, как только установленноe время < сейчас
    GET_TASKS = """
    SELECT chat_id, message FROM users WHERE date_time < datetime('now', '+3 hours');
    """
    # молодец, теперь удали (чтоб не спамить, времени присвой NULL)
    DELETE_TIME = """
    UPDATE users SET date_time = NULL WHERE date_time < datetime('now', '+3 hours');
    """

    # инициализируй в ремайндере поля
    def __init__(self, telegram_client: TelegramClient, database_client: SQLiteClient):
        self.telegram_client = telegram_client  # вот тебе клиент
        self.database_client = database_client  # вот тебе база данных

    # метод создающий коннект с базой данных
    def setup(self):
        self.database_client.create_conn()

    # метод прекращающий коннект с базой данных
    def shutdown(self):
        self.database_client.close_conn()

    #!!! метод который наконец-то отправляет напоминание!!!
    def notify(self, chat_ids: dict):# на входе принимает список id
        if chat_ids:# если список не пустой
            for key in chat_ids:
                self.telegram_client.post(method="sendMessage", params={"text": chat_ids[key], "chat_id": key}) #отправь)0)
            self.database_client.execute_delete_command(self.DELETE_TIME) # молодец, удоли

    # метод, забирающий все таски из базы
    def execute(self):
        chat_ids = self.database_client.execute_select_command(self.GET_TASKS) #иди в сохраненную бд и возьми от туда задачи
        self.notify(chat_ids={key: value for key, value in chat_ids}) #сделай нотифай

    # метод, позволяющий делать объекты класса вызываемыми
    def __call__(self, *args, **kwargs):
        self.execute()


# у нас ремайндер запускается отдельным питон-процессом, вот мы ему все отдаем:
database_client = SQLiteClient("../users.db")
telegram_client = TelegramClient(token=API_TOKEN, base_url="https://api.telegram.org")
reminder = Reminder(telegram_client=telegram_client, database_client=database_client)
reminder.setup()

while True:
    reminder()
    time.sleep(0) #наш бот самый пунктуальный, поэтому задержки команды не будет
