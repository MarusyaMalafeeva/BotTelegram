import requests


# пишем клиент для обработки сырых запросов на классе ООП
# клиент взаимодействует с сервером и манипулирует данными не в пайчарте а на сервере
# клиент нужен для логирования: бот отчитывается об ошибках и работе админу)))
# берегите свои данные и не пишите гадости боту, мы все видим
class TelegramClient:
    def __init__(self, token: str, base_url: str):
        self.token = token
        self.base_url = base_url

    # инициализируй экземпляр с определенным значением полей
    def prepare_url(self, method: str):
        result_url = f"{self.base_url}/bot{self.token}/"
        if method is not None:
            result_url += method
        return result_url

    # метод подготовь юрл
    def post(self, method: str = None, params: dict = None, body: dict = None):  # присвой дефолтные значения
        url = self.prepare_url(method)  # вот тебе наш юрл
        resp = requests.post(url, params=params, data=body)  # сходи и отправь на него все, что узнал
        return resp.json()  # на выходе пж дай джейсон где все хорошо


# метод осуществи запрос.

if __name__ == '__main__':
    # отдаем все, что у нас есть
    token = '7039163457:AAH8K2kdFEdtt6JKxor_zFQfyAbjTb-jJIc'
    telegram_client = TelegramClient(token=token, base_url='https://api.telegram.org')
    my_params = {"chat_id": 1400493857, "text": "Дарина и Маруся лучшие"}
    # налаживаем коммуникацию
    print(telegram_client.post(method="sendMessage", params=my_params))
