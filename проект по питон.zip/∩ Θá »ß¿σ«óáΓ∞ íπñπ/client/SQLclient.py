import datetime
import sqlite3


# чтобы бот не ложился нам прошлось создать базу данных на основе sqlite
# вот так мы создали саму таблицу бд

# conn = sqlite3.connect('users.db')

# CREATE_QUERTY = """
#   CREATE TABLE IF NOT EXISTS users (
#       users_id int PRIMARY KEY,
#       username text,
#       chat_id int
#   );
# """
# conn.execute(CREATE_QUERTY)
# conn.execute("""INSERT INTO users (users_id, username, chat_id) VALUES (1, 'example', 123456);""")

# conn.commit()


# мы опять решили написать класс по логике предыдущего кода(((
class SQLiteClient:
    # инициализация коннекта
    def __init__(self, filepath: str):
        self.filepath = filepath
        self.conn = None

    # метод, создающий коннект
    def create_conn(self):
        self.conn = sqlite3.connect(self.filepath, check_same_thread=False)  # проверяет потоки

    # метод, закрывающий коннект
    def close_conn(self):
        self.conn.close()

    # метод принимающий и сохраняющий данные
    def execute_command(self, command: str, params: tuple):
        if self.conn is not None:
            self.conn.execute(command, params)
            self.conn.commit()
        else:
            raise ConnectionError("Необходимо создать базу данных. Вы обкосячились")

    # метод принимающий и возвращающий данные внутрь кода (кэшбэк)
    def execute_select_command(self, command: str):
        if self.conn is not None:
            cur = self.conn.cursor()  # курсор чекает инфу
            cur.execute(command)
            return cur.fetchall()
        else:
            raise ConnectionError("Необходимо создать базу данных. Вы обкосячились")

    # метод удаляющий данные
    def execute_delete_command(self, command: str):
        if self.conn is not None:
            cur = self.conn.cursor()
            cur.execute(command)
            self.conn.commit()
        else:
            raise ConnectionError("Необходимо создать базу данных. Вы и юзер обкосячились")


class UserActioner:
    # создаем атрибуты класса
    # нам нужны методы, которые на входе будут принимать данные в определенном формате
    # и соответсвовать друг другу
    GET_USER = """
    SELECT user_id, username, chat_id FROM users WHERE user_id = %s;
    """

    CREATE_USER = """
    INSERT INTO users (user_id, username, chat_id) VALUES (?, ?, ?);
    """

    CREATE_REMIND = """
    UPDATE users SET message = ? WHERE user_id = ?;
    """

    CREATE_DATIME = """
    UPDATE users SET date_time = ? WHERE user_id = ?;
    """

    # метод инциализирует базу данных
    def __init__(self, database_client: SQLiteClient):
        self.database_client = database_client

    # метод устанавливает коннект с базой данных
    def setup(self):
        self.database_client.create_conn()

    # метод вносящий пользователя
    def get_user(self, user_id: str):
        user = self.database_client.execute_select_command(self.GET_USER % user_id)
        return user[0] if user else user
# короче, если не писал мы его кэшбэкаем в базу данных, если писал - остается, где был
    # if user == user:
    # return user[0]
    # else:
    # user

    # метод закрывает коннект с базой данных
    def shutdown(self):
        self.database_client.close_conn()

    # метод создает юзер
    def create_user(self, user_id: str, username: str, chat_id: int):
        self.database_client.execute_command(self.CREATE_USER, (user_id, username, chat_id))

    # метод создает напоминание
    def create_remind(self, user_id: str, message: str):
        self.database_client.execute_command(self.CREATE_REMIND, (message, user_id))

    # метод создает дату
    def create_date(self, user_id: str, user_date: datetime):
        self.database_client.execute_command(self.CREATE_DATIME, (user_date, user_id))
